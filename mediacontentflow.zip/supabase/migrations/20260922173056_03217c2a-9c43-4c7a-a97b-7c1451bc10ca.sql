-- enums
CREATE TYPE public.app_role AS ENUM ('creator', 'client');
CREATE TYPE public.content_status AS ENUM ('ideia','a_gravar','gravado','em_ajuste','aprovado','publicado');
CREATE TYPE public.platform AS ENUM ('instagram_reels','tiktok','youtube_shorts','youtube_long','carousel','stories','linkedin');

-- profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  email text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- roles
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

-- clients
CREATE TABLE public.clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company text,
  niche text,
  email text,
  phone text,
  instagram text,
  theme_color text NOT NULL DEFAULT 'moss',
  drive_folder_url text,
  notes text,
  archived boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clients TO authenticated;
GRANT ALL ON public.clients TO service_role;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

-- client access mapping
CREATE TABLE public.client_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, client_id)
);
GRANT SELECT, INSERT, DELETE ON public.client_users TO authenticated;
GRANT ALL ON public.client_users TO service_role;
ALTER TABLE public.client_users ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.current_client_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT client_id FROM public.client_users WHERE user_id = auth.uid() LIMIT 1;
$$;

-- contents
CREATE TABLE public.contents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  title text NOT NULL,
  hook text,
  scheduled_date date,
  scheduled_time text,
  platform public.platform NOT NULL DEFAULT 'instagram_reels',
  status public.content_status NOT NULL DEFAULT 'ideia',
  media_url text,
  briefing text,
  script_text text,
  caption text,
  client_approved_at timestamptz,
  client_adjustment_notes text,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX contents_client_idx ON public.contents (client_id, scheduled_date);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contents TO authenticated;
GRANT ALL ON public.contents TO service_role;
ALTER TABLE public.contents ENABLE ROW LEVEL SECURITY;

-- comments
CREATE TABLE public.content_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL REFERENCES public.contents(id) ON DELETE CASCADE,
  author_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  author_name text NOT NULL,
  author_role public.app_role NOT NULL DEFAULT 'creator',
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX content_comments_content_idx ON public.content_comments (content_id, created_at);
GRANT SELECT, INSERT, DELETE ON public.content_comments TO authenticated;
GRANT ALL ON public.content_comments TO service_role;
ALTER TABLE public.content_comments ENABLE ROW LEVEL SECURITY;

-- policies: profiles
CREATE POLICY "own profile read" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(), 'creator'));
CREATE POLICY "own profile write" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());

-- policies: user_roles
CREATE POLICY "read own roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'creator'));

-- policies: clients
CREATE POLICY "creators manage clients" ON public.clients FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'creator')) WITH CHECK (public.has_role(auth.uid(), 'creator'));
CREATE POLICY "clients read own client" ON public.clients FOR SELECT TO authenticated
  USING (id = public.current_client_id());

-- policies: client_users
CREATE POLICY "creators manage client access" ON public.client_users FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'creator')) WITH CHECK (public.has_role(auth.uid(), 'creator'));
CREATE POLICY "read own access" ON public.client_users FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- policies: contents
CREATE POLICY "creators manage contents" ON public.contents FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'creator')) WITH CHECK (public.has_role(auth.uid(), 'creator'));
CREATE POLICY "clients read own contents" ON public.contents FOR SELECT TO authenticated
  USING (client_id = public.current_client_id());
CREATE POLICY "clients update own contents" ON public.contents FOR UPDATE TO authenticated
  USING (client_id = public.current_client_id()) WITH CHECK (client_id = public.current_client_id());

-- policies: comments
CREATE POLICY "creators manage comments" ON public.content_comments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'creator')) WITH CHECK (public.has_role(auth.uid(), 'creator'));
CREATE POLICY "clients read own comments" ON public.content_comments FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.contents c WHERE c.id = content_id AND c.client_id = public.current_client_id()));
CREATE POLICY "clients add comments" ON public.content_comments FOR INSERT TO authenticated
  WITH CHECK (author_id = auth.uid() AND EXISTS (SELECT 1 FROM public.contents c WHERE c.id = content_id AND c.client_id = public.current_client_id()));

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER clients_updated_at BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER contents_updated_at BEFORE UPDATE ON public.contents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- new user handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email), NEW.email)
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (
    NEW.id,
    CASE WHEN NEW.raw_user_meta_data->>'role' = 'client' THEN 'client'::public.app_role
         ELSE 'creator'::public.app_role END
  )
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

UPDATE public.clients SET created_by = (SELECT user_id FROM public.user_roles WHERE role = 'creator' LIMIT 1) WHERE created_by IS NULL;

CREATE OR REPLACE FUNCTION public.owns_client(_client_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.clients c
    WHERE c.id = _client_id AND c.created_by = auth.uid()
  )
$$;

DROP POLICY IF EXISTS "creators manage clients" ON public.clients;
CREATE POLICY "creators manage own clients" ON public.clients
FOR ALL TO authenticated
USING (has_role(auth.uid(), 'creator'::app_role) AND created_by = auth.uid())
WITH CHECK (has_role(auth.uid(), 'creator'::app_role) AND created_by = auth.uid());

DROP POLICY IF EXISTS "creators manage contents" ON public.contents;
CREATE POLICY "creators manage own contents" ON public.contents
FOR ALL TO authenticated
USING (has_role(auth.uid(), 'creator'::app_role) AND public.owns_client(client_id))
WITH CHECK (has_role(auth.uid(), 'creator'::app_role) AND public.owns_client(client_id));

DROP POLICY IF EXISTS "creators manage comments" ON public.content_comments;
CREATE POLICY "creators manage own comments" ON public.content_comments
FOR ALL TO authenticated
USING (has_role(auth.uid(), 'creator'::app_role) AND EXISTS (SELECT 1 FROM public.contents c WHERE c.id = content_id AND public.owns_client(c.client_id)))
WITH CHECK (has_role(auth.uid(), 'creator'::app_role) AND EXISTS (SELECT 1 FROM public.contents c WHERE c.id = content_id AND public.owns_client(c.client_id)));

DROP POLICY IF EXISTS "creators manage client access" ON public.client_users;
CREATE POLICY "creators manage own client access" ON public.client_users
FOR ALL TO authenticated
USING (has_role(auth.uid(), 'creator'::app_role) AND public.owns_client(client_id))
WITH CHECK (has_role(auth.uid(), 'creator'::app_role) AND public.owns_client(client_id));
import { useEffect, useState } from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — ContentFlow" },
      {
        name: "description",
        content: "Acesse seu painel de produção de conteúdo ou o portal de aprovação do cliente.",
      },
      { property: "og:title", content: "Entrar — ContentFlow" },
      {
        property: "og:description",
        content: "Acesse seu painel de produção de conteúdo ou o portal de aprovação.",
      },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"entrar" | "criar">("entrar");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void supabase.auth.getSession().then(async ({ data }) => {
      if (!data.session) return;
      const { data: access } = await supabase
        .from("client_users")
        .select("client_id")
        .eq("user_id", data.session.user.id)
        .maybeSingle();
      void navigate({ to: access ? "/portal" : "/painel" });
    });
  }, [navigate]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      if (mode === "criar") {
        const { data, error } = await supabase.auth.signUp({
          email: form.email,
          password: form.password,
          options: {
            emailRedirectTo: `${window.location.origin}/painel`,
            data: { full_name: form.name },
          },
        });
        if (error) throw error;
        toast.success("Conta criada.");
        if (data.session) void navigate({ to: "/painel" });
        else setMode("entrar");
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: form.email,
          password: form.password,
        });
        if (error) throw error;
        const { data: access } = await supabase
          .from("client_users")
          .select("client_id")
          .eq("user_id", data.user.id)
          .maybeSingle();
        void navigate({ to: access ? "/portal" : "/painel" });
      }
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-paper px-6">
      <div className="w-full max-w-sm">
        <Link to="/" className="font-display text-lg tracking-tight">
          Content<span className="text-moss">Flow</span>
        </Link>
        <h1 className="mt-6 text-3xl">{mode === "entrar" ? "Entrar" : "Criar conta"}</h1>
        <p className="mt-2 text-sm text-ink-soft">
          {mode === "entrar"
            ? "Equipe e clientes entram pelo mesmo lugar."
            : "Crie sua conta de produtor de conteúdo."}
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "criar" && (
            <div className="space-y-2">
              <Label htmlFor="name">Seu nome</Label>
              <Input
                id="name"
                required
                value={form.name}
                onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
              />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input
              id="email"
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              required
              minLength={6}
              value={form.password}
              onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
            />
          </div>
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Aguarde…" : mode === "entrar" ? "Entrar" : "Criar conta"}
          </Button>
        </form>

        <button
          type="button"
          onClick={() => setMode(mode === "entrar" ? "criar" : "entrar")}
          className="mt-4 text-sm text-moss underline underline-offset-4"
        >
          {mode === "entrar" ? "Não tenho conta ainda" : "Já tenho conta"}
        </button>
      </div>
    </div>
  );
}

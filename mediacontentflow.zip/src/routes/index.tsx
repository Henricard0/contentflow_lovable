import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarDays, MessageSquareQuote, Columns3 } from "lucide-react";
import heroImage from "@/assets/mesa-edicao.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ContentFlow — a mesa de edição dos seus clientes" },
      {
        name: "description",
        content:
          "Organize roteiros, gravações e aprovações de conteúdo dos seus clientes em um só painel: quadro, tabela, calendário e portal de aprovação.",
      },
      { property: "og:title", content: "ContentFlow — a mesa de edição dos seus clientes" },
      {
        property: "og:description",
        content:
          "Roteiros, gravações e aprovações de conteúdo em um só painel, com portal próprio para cada cliente.",
      },
    ],
  }),
  component: Landing,
});

const features = [
  {
    icon: Columns3,
    title: "Quadro por etapa",
    body: "Ideia, a gravar, gravado, em ajuste, aprovado e publicado. Arraste e a produção anda.",
  },
  {
    icon: CalendarDays,
    title: "Calendário e tabela",
    body: "A mesma pauta em três visões, para planejar o mês ou executar o dia.",
  },
  {
    icon: MessageSquareQuote,
    title: "Portal do cliente",
    body: "Ele aprova ou pede ajuste com um comentário. Você recebe direto no card.",
  },
];

function Landing() {
  return (
    <div className="min-h-screen bg-paper">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <span className="font-display text-lg tracking-tight">
          Content<span className="text-moss">Flow</span>
        </span>
        <Link
          to="/auth"
          className="rounded-full bg-ink px-4 py-2 text-sm font-medium text-paper transition-opacity hover:opacity-90"
        >
          Entrar
        </Link>
      </header>

      <main className="mx-auto max-w-6xl px-6 pb-24">
        <section className="grid items-center gap-10 py-10 lg:grid-cols-[1.05fr_1fr] lg:py-16">
          <div>
            <p className="label-mono text-moss">produção de conteúdo sob controle</p>
            <h1 className="mt-4 text-4xl leading-[1.05] sm:text-5xl lg:text-6xl">
              A mesa de edição
              <br />
              dos seus clientes.
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-ink-soft">
              Um lugar só para roteiro, agenda, material gravado e aprovação. Cada cliente entra no
              portal dele, aprova o que está pronto e pede ajuste onde precisa — sem grupos de
              mensagens perdidos.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                to="/auth"
                className="inline-flex items-center gap-2 rounded-full bg-moss px-5 py-3 text-sm font-medium text-paper transition-opacity hover:opacity-90"
              >
                Abrir meu painel <ArrowRight className="size-4" />
              </Link>
              <span className="text-sm text-faint">Grátis para começar.</span>
            </div>
          </div>

          <img
            src={heroImage}
            alt="Mesa de edição com calendário de conteúdo, roteiros e câmera"
            loading="lazy"
            width={1024}
            height={768}
            className="w-full rounded-2xl object-cover shadow-[0_24px_60px_-30px_oklch(0.28_0.017_48.1/0.55)]"
          />
        </section>

        <section className="grid gap-4 sm:grid-cols-3">
          {features.map(({ icon: Icon, title, body }) => (
            <article key={title} className="paper-card p-5">
              <Icon className="size-5 text-moss" />
              <h2 className="mt-3 text-lg">{title}</h2>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{body}</p>
            </article>
          ))}
        </section>
      </main>

      <footer className="border-t border-line/70 py-8">
        <p className="mx-auto max-w-6xl px-6 text-sm text-faint">
          ContentFlow · feito para quem produz conteúdo para outras marcas.
        </p>
      </footer>
    </div>
  );
}

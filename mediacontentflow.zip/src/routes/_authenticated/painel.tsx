import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { LogOut, Plus, Search, Users } from "lucide-react";
import { toast } from "sonner";
import { useAuth, signOut } from "@/hooks/useAuth";
import { useClients, useContents, useUpdateContent, type Client, type Content } from "@/lib/data";
import { STATUS_LABEL, initials, isoWeekLabel, longDate, todayISO } from "@/lib/domain";
import type { ContentStatus } from "@/lib/domain";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { KanbanBoard } from "@/components/app/KanbanBoard";
import { ContentTable } from "@/components/app/ContentTable";
import { CalendarView } from "@/components/app/CalendarView";
import { ContentDialog } from "@/components/app/ContentDialog";
import { ClientDialog } from "@/components/app/ClientDialog";
import { StatusChip } from "@/components/app/StatusChip";
import { cn } from "@/lib/utils";
import heroImage from "@/assets/mesa-edicao.jpg";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Painel — ContentFlow" },
      {
        name: "description",
        content: "Quadro, calendário e tabela da produção de conteúdo de todos os seus clientes.",
      },
      { property: "og:title", content: "Painel — ContentFlow" },
      {
        property: "og:description",
        content: "Quadro, calendário e tabela da produção de conteúdo dos seus clientes.",
      },
    ],
  }),
  component: Painel,
});

function Painel() {
  const navigate = useNavigate();
  const { session, role, clientId, fullName, loading } = useAuth();
  const [selectedClient, setSelectedClient] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [contentDialog, setContentDialog] = useState<{
    open: boolean;
    content: Content | null;
    status?: ContentStatus | undefined;
    date?: string | undefined;
  }>({ open: false, content: null });
  const [clientDialog, setClientDialog] = useState<{ open: boolean; client: Client | null }>({
    open: false,
    client: null,
  });

  const isCreator = role === "creator";
  const clients = useClients(isCreator);
  const contents = useContents(isCreator ? selectedClient : undefined);
  const updateContent = useUpdateContent();

  useEffect(() => {
    if (!loading && role === "client" && clientId) void navigate({ to: "/portal" });
  }, [loading, role, clientId, navigate]);

  useEffect(() => {
    if (!selectedClient && clients.data?.length) setSelectedClient(clients.data[0]!.id);
  }, [clients.data, selectedClient]);

  const activeClient = clients.data?.find((c) => c.id === selectedClient) ?? null;
  const items = useMemo(() => {
    const list = contents.data ?? [];
    const term = search.trim().toLowerCase();
    if (!term) return list;
    return list.filter(
      (c) =>
        c.title.toLowerCase().includes(term) || (c.hook ?? "").toLowerCase().includes(term),
    );
  }, [contents.data, search]);

  const pending = (contents.data ?? []).filter(
    (c) => c.status === "em_ajuste" || (c.status === "gravado" && !c.client_approved_at),
  );
  const today = todayISO();
  const upcoming = (contents.data ?? [])
    .filter((c) => c.scheduled_date && c.scheduled_date >= today && c.status !== "publicado")
    .slice(0, 4);

  if (loading) {
    return <p className="p-10 text-sm text-muted-foreground">Carregando seu painel…</p>;
  }

  if (!isCreator) {
    return (
      <div className="p-10">
        <p className="text-sm text-muted-foreground">
          Esta área é da equipe. Se você é cliente, abra o portal de aprovação.
        </p>
        <Button className="mt-4" onClick={() => navigate({ to: "/portal" })}>
          Ir para o portal
        </Button>
      </div>
    );
  }

  const openNew = (status?: ContentStatus, date?: string) => {
    if (!selectedClient) {
      toast.error("Crie ou selecione um cliente primeiro.");
      return;
    }
    setContentDialog({ open: true, content: null, status, date });
  };

  return (
    <div className="flex min-h-screen bg-paper">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-line/70 bg-surface lg:flex">
        <div className="px-5 py-5">
          <span className="font-display text-lg tracking-tight">
            Content<span className="text-moss">Flow</span>
          </span>
          <p className="label-mono mt-1 text-faint">{isoWeekLabel()}</p>
        </div>

        <div className="flex items-center justify-between px-5 pb-2">
          <span className="label-mono text-faint">clientes</span>
          <button
            type="button"
            onClick={() => setClientDialog({ open: true, client: null })}
            aria-label="Novo cliente"
            className="rounded-md p-1 text-faint hover:bg-paper-deep hover:text-ink"
          >
            <Plus className="size-4" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {(clients.data ?? []).map((client) => (
            <button
              key={client.id}
              type="button"
              onClick={() => setSelectedClient(client.id)}
              onDoubleClick={() => setClientDialog({ open: true, client })}
              className={cn(
                "flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left text-sm transition-colors",
                client.id === selectedClient
                  ? "bg-moss-soft text-accent-foreground"
                  : "hover:bg-paper-deep",
              )}
            >
              <span className="label-mono grid size-7 place-items-center rounded-full bg-paper-deep text-ink-soft">
                {initials(client.name)}
              </span>
              <span className="truncate">{client.name}</span>
            </button>
          ))}
          {clients.data?.length === 0 && (
            <p className="px-2 py-3 text-xs text-muted-foreground">
              Nenhum cliente ainda. Comece criando o primeiro.
            </p>
          )}
        </nav>

        <div className="border-t border-line/70 px-5 py-4">
          <p className="truncate text-sm">{fullName}</p>
          <button
            type="button"
            onClick={async () => {
              await signOut();
              void navigate({ to: "/auth" });
            }}
            className="mt-1 inline-flex items-center gap-1.5 text-xs text-faint hover:text-wine"
          >
            <LogOut className="size-3.5" /> Sair
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1">
        <header className="flex flex-wrap items-center gap-3 border-b border-line/70 bg-surface px-6 py-4">
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-2xl">{activeClient?.name ?? "Selecione um cliente"}</h1>
            <p className="text-sm text-faint">
              {activeClient?.niche || activeClient?.company || "—"}
            </p>
          </div>
          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar conteúdo"
              className="w-56 pl-9"
            />
          </div>
          <Button variant="outline" onClick={() => setClientDialog({ open: true, client: activeClient })} disabled={!activeClient}>
            <Users className="size-4" /> Cliente
          </Button>
          <Button onClick={() => openNew()}>
            <Plus className="size-4" /> Novo conteúdo
          </Button>
        </header>

        <div className="space-y-6 p-6">
          <section className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
            <div className="relative overflow-hidden rounded-2xl">
              <img
                src={heroImage}
                alt="Mesa de edição com calendário, roteiros e câmera"
                loading="lazy"
                className="h-44 w-full object-cover"
              />
              <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-ink/70 to-transparent p-5">
                <p className="label-mono text-paper/70">pauta da semana</p>
                <p className="font-display text-2xl text-paper">
                  {(contents.data ?? []).length} conteúdos em produção
                </p>
              </div>
            </div>

            <div className="paper-card p-5">
              <p className="label-mono text-faint">precisa de você</p>
              <div className="mt-3 space-y-2">
                {pending.length === 0 && (
                  <p className="text-sm text-muted-foreground">Nada pendente. Respire.</p>
                )}
                {pending.slice(0, 4).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setContentDialog({ open: true, content: item })}
                    className="flex w-full items-center justify-between gap-3 rounded-lg bg-paper-deep/60 px-3 py-2 text-left text-sm hover:bg-paper-deep"
                  >
                    <span className="truncate">{item.title}</span>
                    <StatusChip status={item.status} />
                  </button>
                ))}
              </div>
              {upcoming.length > 0 && (
                <>
                  <p className="label-mono mt-5 text-faint">próximas datas</p>
                  <ul className="mt-2 space-y-1 text-sm text-ink-soft">
                    {upcoming.map((item) => (
                      <li key={item.id} className="flex justify-between gap-3">
                        <span className="truncate">{item.title}</span>
                        <span className="shrink-0 text-faint">{longDate(item.scheduled_date)}</span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </section>

          <Tabs defaultValue="quadro">
            <TabsList>
              <TabsTrigger value="quadro">Quadro</TabsTrigger>
              <TabsTrigger value="tabela">Tabela</TabsTrigger>
              <TabsTrigger value="calendario">Calendário</TabsTrigger>
            </TabsList>

            <TabsContent value="quadro" className="pt-4">
              <KanbanBoard
                contents={items}
                onOpen={(content) => setContentDialog({ open: true, content })}
                onCreate={(status) => openNew(status)}
                onMove={(id, status) => {
                  updateContent.mutate({ id, patch: { status } });
                  toast.success(`Movido para ${STATUS_LABEL[status]}.`);
                }}
              />
            </TabsContent>
            <TabsContent value="tabela" className="pt-4">
              <ContentTable
                contents={items}
                onOpen={(content) => setContentDialog({ open: true, content })}
              />
            </TabsContent>
            <TabsContent value="calendario" className="pt-4">
              <CalendarView
                contents={items}
                onOpen={(content) => setContentDialog({ open: true, content })}
                onCreate={(date) => openNew(undefined, date)}
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {selectedClient && (
        <ContentDialog
          open={contentDialog.open}
          onOpenChange={(open) => setContentDialog((prev) => ({ ...prev, open }))}
          clientId={selectedClient}
          content={contentDialog.content}
          defaultDate={contentDialog.date}
          defaultStatus={contentDialog.status}
          author={{ id: session?.user.id ?? null, name: fullName }}
        />
      )}

      <ClientDialog
        open={clientDialog.open}
        onOpenChange={(open) => setClientDialog((prev) => ({ ...prev, open }))}
        client={clientDialog.client}
      />
    </div>
  );
}

import { useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CheckCircle2, LogOut, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { useAuth, signOut } from "@/hooks/useAuth";
import {
  useAddComment,
  useClients,
  useComments,
  useContents,
  useUpdateContent,
  type Content,
} from "@/lib/data";
import { PLATFORM_LABEL, longDate } from "@/lib/domain";
import { StatusChip } from "@/components/app/StatusChip";
import { CommentThread } from "@/components/app/CommentThread";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/portal")({
  head: () => ({
    meta: [
      { title: "Portal de aprovação — ContentFlow" },
      {
        name: "description",
        content: "Veja os conteúdos preparados para você, aprove ou peça ajustes com um comentário.",
      },
      { property: "og:title", content: "Portal de aprovação — ContentFlow" },
      {
        property: "og:description",
        content: "Aprove conteúdos ou peça ajustes direto para quem produz.",
      },
    ],
  }),
  component: Portal,
});

function Portal() {
  const navigate = useNavigate();
  const { session, role, clientId, fullName, loading } = useAuth();
  const contents = useContents(clientId);
  const clients = useClients(false);
  const update = useUpdateContent();
  const addComment = useAddComment();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [adjustment, setAdjustment] = useState("");

  const list = useMemo(
    () => (contents.data ?? []).filter((c) => c.status !== "ideia"),
    [contents.data],
  );
  const selected: Content | null = list.find((c) => c.id === selectedId) ?? list[0] ?? null;
  const comments = useComments(selected?.id ?? null);

  if (loading) return <p className="p-10 text-sm text-muted-foreground">Carregando…</p>;

  if (role === "creator" && !clientId) {
    return (
      <div className="p-10">
        <p className="text-sm text-muted-foreground">
          Esta é a área do cliente. Seu painel de produção fica em outro lugar.
        </p>
        <Button className="mt-4" onClick={() => navigate({ to: "/painel" })}>
          Ir para o painel
        </Button>
      </div>
    );
  }

  const approve = async () => {
    if (!selected) return;
    await update.mutateAsync({
      id: selected.id,
      patch: {
        status: "aprovado",
        client_approved_at: new Date().toISOString(),
        client_adjustment_notes: null,
      },
    });
    toast.success("Conteúdo aprovado.");
  };

  const requestAdjustment = async () => {
    if (!selected) return;
    if (!adjustment.trim()) {
      toast.error("Escreva o que precisa mudar.");
      return;
    }
    await update.mutateAsync({
      id: selected.id,
      patch: {
        status: "em_ajuste",
        client_approved_at: null,
        client_adjustment_notes: adjustment.trim(),
      },
    });
    await addComment.mutateAsync({
      content_id: selected.id,
      author_id: session?.user.id ?? null,
      author_name: fullName,
      author_role: "client",
      body: adjustment.trim(),
    });
    setAdjustment("");
    toast.success("Pedido de ajuste enviado.");
  };

  return (
    <div className="min-h-screen bg-paper">
      <header className="flex items-center justify-between border-b border-line/70 bg-surface px-6 py-4">
        <div>
          <span className="font-display text-lg tracking-tight">
            Content<span className="text-moss">Flow</span>
          </span>
          <p className="label-mono text-faint">
            portal de {clients.data?.[0]?.name ?? fullName}
          </p>
        </div>
        <button
          type="button"
          onClick={async () => {
            await signOut();
            void navigate({ to: "/auth" });
          }}
          className="inline-flex items-center gap-1.5 text-xs text-faint hover:text-wine"
        >
          <LogOut className="size-3.5" /> Sair
        </button>
      </header>

      <main className="mx-auto grid max-w-6xl gap-6 p-6 lg:grid-cols-[320px_1fr]">
        <section className="space-y-2">
          <p className="label-mono text-faint">seus conteúdos</p>
          {list.length === 0 && (
            <p className="text-sm text-muted-foreground">
              Nada para revisar por enquanto. Assim que algo estiver pronto, aparece aqui.
            </p>
          )}
          {list.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSelectedId(item.id)}
              className={cn(
                "w-full rounded-xl bg-surface p-4 text-left ring-1 transition-shadow hover:shadow-sm",
                selected?.id === item.id ? "ring-moss" : "ring-line/70",
              )}
            >
              <p className="text-sm font-medium">{item.title}</p>
              <p className="label-mono mt-1 text-faint">
                {PLATFORM_LABEL[item.platform]} · {longDate(item.scheduled_date)}
              </p>
              <StatusChip status={item.status} className="mt-2" />
            </button>
          ))}
        </section>

        {selected && (
          <section className="space-y-5">
            <div className="paper-card p-6">
              <StatusChip status={selected.status} />
              <h1 className="mt-3 text-2xl">{selected.title}</h1>
              {selected.hook && (
                <p className="mt-2 border-l-2 border-moss pl-3 font-display text-lg text-ink-soft italic">
                  “{selected.hook}”
                </p>
              )}
              {selected.media_url && (
                <a
                  href={selected.media_url}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-4 inline-block text-sm text-moss underline underline-offset-4"
                >
                  Ver material gravado
                </a>
              )}
              {selected.caption && (
                <div className="mt-5">
                  <p className="label-mono text-faint">legenda</p>
                  <p className="mt-1 text-sm whitespace-pre-line">{selected.caption}</p>
                </div>
              )}
              {selected.client_approved_at && (
                <p className="mt-5 inline-flex items-center gap-1.5 text-sm text-moss">
                  <CheckCircle2 className="size-4" /> Aprovado por você
                </p>
              )}
            </div>

            <div className="paper-card space-y-3 p-6">
              <p className="label-mono text-faint">sua resposta</p>
              <div className="flex flex-wrap gap-2">
                <Button onClick={approve} disabled={update.isPending}>
                  <CheckCircle2 className="size-4" /> Aprovar
                </Button>
              </div>
              <Textarea
                rows={3}
                value={adjustment}
                onChange={(e) => setAdjustment(e.target.value)}
                placeholder="Precisa mudar algo? Descreva aqui."
              />
              <Button variant="outline" onClick={requestAdjustment} disabled={update.isPending}>
                <RotateCcw className="size-4" /> Pedir ajuste
              </Button>
              {selected.client_adjustment_notes && (
                <p className="rounded-lg bg-wine-soft px-3 py-2 text-sm text-wine">
                  Último pedido: {selected.client_adjustment_notes}
                </p>
              )}
            </div>

            <div className="paper-card p-6">
              <p className="label-mono mb-3 text-faint">conversa</p>
              <CommentThread
                comments={comments.data ?? []}
                loading={comments.isLoading}
                onSend={async (body) => {
                  await addComment.mutateAsync({
                    content_id: selected.id,
                    author_id: session?.user.id ?? null,
                    author_name: fullName,
                    author_role: "client",
                    body,
                  });
                }}
              />
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const schema = z.object({
  clientId: z.string().uuid(),
  email: z.string().email(),
  password: z.string().min(6),
  fullName: z.string().min(1),
});

/**
 * Creates (or re-links) a login for a client so they can open their portal.
 * Only a signed-in team member (creator role) may call this.
 */
export const createClientAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => schema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: isCreator, error: roleError } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "creator",
    });
    if (roleError) throw new Error(roleError.message);
    if (!isCreator) throw new Error("Apenas a equipe pode criar acessos de cliente.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let userId: string | null = null;
    const created = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.fullName, role: "client" },
    });

    if (created.error) {
      const list = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
      const existing = list.data?.users.find(
        (u) => u.email?.toLowerCase() === data.email.toLowerCase(),
      );
      if (!existing) throw new Error(created.error.message);
      userId = existing.id;
      await supabaseAdmin.auth.admin.updateUserById(existing.id, { password: data.password });
    } else {
      userId = created.data.user?.id ?? null;
    }

    if (!userId) throw new Error("Não foi possível criar o acesso.");

    const { data: existingRole } = await supabaseAdmin
      .from("user_roles")
      .select("id")
      .eq("user_id", userId)
      .eq("role", "client")
      .maybeSingle();
    if (!existingRole) {
      await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "client" });
    }

    const { data: link } = await supabaseAdmin
      .from("client_users")
      .select("id")
      .eq("user_id", userId)
      .maybeSingle();
    if (link) {
      const { error } = await supabaseAdmin
        .from("client_users")
        .update({ client_id: data.clientId })
        .eq("id", link.id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin
        .from("client_users")
        .insert({ user_id: userId, client_id: data.clientId });
      if (error) throw new Error(error.message);
    }

    return { ok: true as const, email: data.email };
  });

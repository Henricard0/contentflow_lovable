import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { ContentStatus, Platform } from "./domain";

export interface Client {
  id: string;
  name: string;
  company: string | null;
  niche: string | null;
  email: string | null;
  phone: string | null;
  instagram: string | null;
  theme_color: string;
  drive_folder_url: string | null;
  notes: string | null;
  archived: boolean;
  created_at: string;
}

export interface Content {
  id: string;
  client_id: string;
  title: string;
  hook: string | null;
  scheduled_date: string | null;
  scheduled_time: string | null;
  platform: Platform;
  status: ContentStatus;
  media_url: string | null;
  briefing: string | null;
  script_text: string | null;
  caption: string | null;
  client_approved_at: string | null;
  client_adjustment_notes: string | null;
  position: number;
  created_at: string;
  updated_at: string;
}

export interface Comment {
  id: string;
  content_id: string;
  author_id: string | null;
  author_name: string;
  author_role: "creator" | "client";
  body: string;
  created_at: string;
}

const table = (name: string) => supabase.from(name as never);

export function useClients(enabled = true) {
  return useQuery({
    queryKey: ["clients"],
    enabled,
    queryFn: async (): Promise<Client[]> => {
      const { data, error } = await table("clients")
        .select("*")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Client[];
    },
  });
}

export function useContents(clientId?: string | null) {
  return useQuery({
    queryKey: ["contents", clientId ?? "all"],
    enabled: clientId !== undefined,
    queryFn: async (): Promise<Content[]> => {
      let query = table("contents").select("*");
      if (clientId) query = query.eq("client_id", clientId);
      const { data, error } = await query
        .order("scheduled_date", { ascending: true, nullsFirst: false })
        .order("position", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Content[];
    },
  });
}

export function useComments(contentId?: string | null) {
  return useQuery({
    queryKey: ["comments", contentId],
    enabled: !!contentId,
    queryFn: async (): Promise<Comment[]> => {
      const { data, error } = await table("content_comments")
        .select("*")
        .eq("content_id", contentId!)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Comment[];
    },
  });
}

export function useSaveClient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: Partial<Client> & { name: string }) => {
      if (values.id) {
        const { id, ...rest } = values;
        const { error } = await table("clients").update(rest as never).eq("id", id);
        if (error) throw error;
        return id;
      }
      const { data: auth } = await supabase.auth.getUser();
      const { data, error } = await table("clients")
        .insert({ ...values, created_by: auth.user?.id } as never)
        .select("id")
        .single();
      if (error) throw error;
      return (data as { id: string }).id;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["clients"] }),
  });
}

export function useDeleteClient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await table("clients").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["clients"] });
      qc.invalidateQueries({ queryKey: ["contents"] });
    },
  });
}

export function useSaveContent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: Partial<Content> & { client_id: string; title: string }) => {
      if (values.id) {
        const { id, ...rest } = values;
        const { error } = await table("contents").update(rest as never).eq("id", id);
        if (error) throw error;
        return id;
      }
      const { data, error } = await table("contents")
        .insert(values as never)
        .select("id")
        .single();
      if (error) throw error;
      return (data as { id: string }).id;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["contents"] }),
  });
}

export function useUpdateContent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<Content> }) => {
      const { error } = await table("contents").update(patch as never).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["contents"] }),
  });
}

export function useDeleteContent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await table("contents").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["contents"] }),
  });
}

export function useAddComment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: {
      content_id: string;
      author_id: string | null;
      author_name: string;
      author_role: "creator" | "client";
      body: string;
    }) => {
      const { error } = await table("content_comments").insert(values as never);
      if (error) throw error;
    },
    onSuccess: (_d, vars) => qc.invalidateQueries({ queryKey: ["comments", vars.content_id] }),
  });
}

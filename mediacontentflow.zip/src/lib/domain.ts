export const STATUSES = [
  "ideia",
  "a_gravar",
  "gravado",
  "em_ajuste",
  "aprovado",
  "publicado",
] as const;

export type ContentStatus = (typeof STATUSES)[number];

export const STATUS_LABEL: Record<ContentStatus, string> = {
  ideia: "Ideia",
  a_gravar: "A gravar",
  gravado: "Gravado",
  em_ajuste: "Em ajuste",
  aprovado: "Aprovado",
  publicado: "Publicado",
};

/** Tailwind classes per status — semantic tokens only. */
export const STATUS_STYLE: Record<ContentStatus, { dot: string; chip: string; ring: string }> = {
  ideia: { dot: "bg-faint", chip: "bg-paper-deep text-muted-foreground", ring: "ring-line/80" },
  a_gravar: { dot: "bg-amber-flag", chip: "bg-amber-soft text-ink", ring: "ring-amber-flag/35" },
  gravado: { dot: "bg-ink-soft", chip: "bg-paper-deep text-ink", ring: "ring-line/80" },
  em_ajuste: { dot: "bg-wine", chip: "bg-wine-soft text-wine", ring: "ring-wine/35" },
  aprovado: { dot: "bg-moss", chip: "bg-moss-soft text-moss", ring: "ring-moss/35" },
  publicado: { dot: "bg-moss", chip: "bg-moss-soft text-moss", ring: "ring-moss/25" },
};

export const PLATFORMS = [
  "instagram_reels",
  "tiktok",
  "youtube_shorts",
  "youtube_long",
  "carousel",
  "stories",
  "linkedin",
] as const;

export type Platform = (typeof PLATFORMS)[number];

export const PLATFORM_LABEL: Record<Platform, string> = {
  instagram_reels: "Reels",
  tiktok: "TikTok",
  youtube_shorts: "Shorts",
  youtube_long: "YouTube",
  carousel: "Carrossel",
  stories: "Stories",
  linkedin: "LinkedIn",
};

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

const MONTHS = [
  "jan",
  "fev",
  "mar",
  "abr",
  "mai",
  "jun",
  "jul",
  "ago",
  "set",
  "out",
  "nov",
  "dez",
];

/** "2026-02-12" -> "12/fev" (date-only, no timezone shifting) */
export function shortDate(value?: string | null) {
  if (!value) return "sem data";
  const [y, m, d] = value.split("-").map(Number);
  if (!y || !m || !d) return value;
  return `${String(d).padStart(2, "0")}/${MONTHS[m - 1]}`;
}

export function longDate(value?: string | null) {
  if (!value) return "sem data";
  const [y, m, d] = value.split("-").map(Number);
  if (!y || !m || !d) return value;
  return `${String(d).padStart(2, "0")} de ${MONTHS[m - 1]} de ${y}`;
}

export function todayISO() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(
    now.getDate(),
  ).padStart(2, "0")}`;
}

export function isoWeekLabel(date = new Date()) {
  const start = new Date(date.getFullYear(), 0, 1);
  const week = Math.ceil(((date.getTime() - start.getTime()) / 86400000 + start.getDay() + 1) / 7);
  return `semana ${week} · ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

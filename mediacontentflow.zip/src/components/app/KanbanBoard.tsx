import { useState } from "react";
import { STATUSES, STATUS_LABEL, STATUS_STYLE, PLATFORM_LABEL, shortDate } from "@/lib/domain";
import type { ContentStatus } from "@/lib/domain";
import type { Content } from "@/lib/data";
import { cn } from "@/lib/utils";
import { Plus } from "lucide-react";

export function KanbanBoard({
  contents,
  onOpen,
  onCreate,
  onMove,
}: {
  contents: Content[];
  onOpen: (content: Content) => void;
  onCreate: (status: ContentStatus) => void;
  onMove: (id: string, status: ContentStatus) => void;
}) {
  const [dragging, setDragging] = useState<string | null>(null);
  const [over, setOver] = useState<ContentStatus | null>(null);

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {STATUSES.map((status) => {
        const items = contents.filter((c) => c.status === status);
        return (
          <section
            key={status}
            onDragOver={(e) => {
              e.preventDefault();
              setOver(status);
            }}
            onDragLeave={() => setOver((s) => (s === status ? null : s))}
            onDrop={() => {
              if (dragging) onMove(dragging, status);
              setDragging(null);
              setOver(null);
            }}
            className={cn(
              "flex min-h-40 flex-col gap-2 rounded-xl bg-paper-deep/60 p-2 transition-colors",
              over === status && "bg-moss-soft/60",
            )}
          >
            <header className="flex items-center justify-between px-1 pt-1">
              <span className="label-mono flex items-center gap-1.5 text-ink-soft">
                <span className={cn("size-1.5 rounded-full", STATUS_STYLE[status].dot)} />
                {STATUS_LABEL[status]}
                <span className="text-faint">{items.length}</span>
              </span>
              <button
                type="button"
                onClick={() => onCreate(status)}
                aria-label={`Novo conteúdo em ${STATUS_LABEL[status]}`}
                className="rounded-md p-1 text-faint transition-colors hover:bg-surface hover:text-ink"
              >
                <Plus className="size-3.5" />
              </button>
            </header>

            {items.map((item) => (
              <article
                key={item.id}
                draggable
                onDragStart={() => setDragging(item.id)}
                onDragEnd={() => setDragging(null)}
                onClick={() => onOpen(item)}
                className={cn(
                  "cursor-pointer rounded-lg bg-surface p-3 text-left ring-1 transition-shadow hover:shadow-md",
                  STATUS_STYLE[item.status].ring,
                  dragging === item.id && "opacity-50",
                )}
              >
                <p className="text-sm leading-snug font-medium">{item.title}</p>
                {item.hook && (
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{item.hook}</p>
                )}
                <p className="label-mono mt-2 text-faint">
                  {PLATFORM_LABEL[item.platform]} · {shortDate(item.scheduled_date)}
                </p>
                {item.client_adjustment_notes && item.status === "em_ajuste" && (
                  <p className="mt-2 rounded bg-wine-soft px-2 py-1 text-[11px] text-wine">
                    pedido de ajuste
                  </p>
                )}
              </article>
            ))}
          </section>
        );
      })}
    </div>
  );
}

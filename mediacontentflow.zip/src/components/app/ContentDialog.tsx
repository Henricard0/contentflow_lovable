import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  PLATFORMS,
  PLATFORM_LABEL,
  STATUSES,
  STATUS_LABEL,
  type ContentStatus,
  type Platform,
} from "@/lib/domain";
import {
  useAddComment,
  useComments,
  useDeleteContent,
  useSaveContent,
  type Content,
} from "@/lib/data";
import { CommentThread } from "./CommentThread";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientId: string;
  content: Content | null;
  defaultDate?: string | undefined;
  defaultStatus?: ContentStatus | undefined;
  author: { id: string | null; name: string };
}

const empty = {
  title: "",
  hook: "",
  scheduled_date: "",
  scheduled_time: "",
  platform: "instagram_reels" as Platform,
  status: "ideia" as ContentStatus,
  media_url: "",
  briefing: "",
  script_text: "",
  caption: "",
};

export function ContentDialog({
  open,
  onOpenChange,
  clientId,
  content,
  defaultDate,
  defaultStatus,
  author,
}: Props) {
  const [form, setForm] = useState(empty);
  const save = useSaveContent();
  const remove = useDeleteContent();
  const comments = useComments(content?.id ?? null);
  const addComment = useAddComment();

  useEffect(() => {
    if (!open) return;
    setForm(
      content
        ? {
            title: content.title,
            hook: content.hook ?? "",
            scheduled_date: content.scheduled_date ?? "",
            scheduled_time: content.scheduled_time ?? "",
            platform: content.platform,
            status: content.status,
            media_url: content.media_url ?? "",
            briefing: content.briefing ?? "",
            script_text: content.script_text ?? "",
            caption: content.caption ?? "",
          }
        : { ...empty, scheduled_date: defaultDate ?? "", status: defaultStatus ?? "ideia" },
    );
  }, [open, content, defaultDate, defaultStatus]);

  const set = <K extends keyof typeof empty>(key: K, value: (typeof empty)[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const handleSave = async () => {
    if (!form.title.trim()) {
      toast.error("Dê um título ao conteúdo.");
      return;
    }
    try {
      await save.mutateAsync({
        id: content?.id,
        client_id: clientId,
        title: form.title.trim(),
        hook: form.hook || null,
        scheduled_date: form.scheduled_date || null,
        scheduled_time: form.scheduled_time || null,
        platform: form.platform,
        status: form.status,
        media_url: form.media_url || null,
        briefing: form.briefing || null,
        script_text: form.script_text || null,
        caption: form.caption || null,
      } as never);
      toast.success(content ? "Conteúdo atualizado." : "Conteúdo criado.");
      onOpenChange(false);
    } catch (error) {
      toast.error((error as Error).message);
    }
  };

  const handleDelete = async () => {
    if (!content) return;
    await remove.mutateAsync(content.id);
    toast.success("Conteúdo removido.");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {content ? "Editar conteúdo" : "Novo conteúdo"}
          </DialogTitle>
          <DialogDescription>
            Roteiro, agenda e material de apoio em um só lugar.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="ficha">
          <TabsList>
            <TabsTrigger value="ficha">Ficha</TabsTrigger>
            <TabsTrigger value="roteiro">Roteiro</TabsTrigger>
            <TabsTrigger value="conversa" disabled={!content}>
              Conversa
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ficha" className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título</Label>
              <Input
                id="title"
                value={form.title}
                onChange={(e) => set("title", e.target.value)}
                placeholder="Ex.: Bastidores da torra de terça"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hook">Gancho</Label>
              <Input
                id="hook"
                value={form.hook}
                onChange={(e) => set("hook", e.target.value)}
                placeholder="A primeira frase do vídeo"
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Plataforma</Label>
                <Select
                  value={form.platform}
                  onValueChange={(v) => set("platform", v as Platform)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PLATFORMS.map((p) => (
                      <SelectItem key={p} value={p}>
                        {PLATFORM_LABEL[p]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Etapa</Label>
                <Select
                  value={form.status}
                  onValueChange={(v) => set("status", v as ContentStatus)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {STATUS_LABEL[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">Data</Label>
                <Input
                  id="date"
                  type="date"
                  value={form.scheduled_date}
                  onChange={(e) => set("scheduled_date", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time">Hora</Label>
                <Input
                  id="time"
                  type="time"
                  value={form.scheduled_time}
                  onChange={(e) => set("scheduled_time", e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="media">Link da mídia (Drive, YouTube, Loom…)</Label>
              <Input
                id="media"
                value={form.media_url}
                onChange={(e) => set("media_url", e.target.value)}
                placeholder="https://"
              />
            </div>
          </TabsContent>

          <TabsContent value="roteiro" className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="briefing">Briefing de gravação</Label>
              <Textarea
                id="briefing"
                rows={4}
                value={form.briefing}
                onChange={(e) => set("briefing", e.target.value)}
                placeholder="Como gravar: enquadramento, luz, cenário…"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="script">Roteiro / teleprompter</Label>
              <Textarea
                id="script"
                rows={7}
                value={form.script_text}
                onChange={(e) => set("script_text", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="caption">Legenda e hashtags</Label>
              <Textarea
                id="caption"
                rows={4}
                value={form.caption}
                onChange={(e) => set("caption", e.target.value)}
              />
            </div>
          </TabsContent>

          <TabsContent value="conversa" className="pt-4">
            {content && (
              <CommentThread
                comments={comments.data ?? []}
                loading={comments.isLoading}
                onSend={async (body) => {
                  await addComment.mutateAsync({
                    content_id: content.id,
                    author_id: author.id,
                    author_name: author.name,
                    author_role: "creator",
                    body,
                  });
                }}
              />
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter className="gap-2 sm:justify-between">
          {content ? (
            <Button variant="ghost" className="text-wine" onClick={handleDelete}>
              Excluir
            </Button>
          ) : (
            <span />
          )}
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={save.isPending}>
              Salvar
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { STATUS_LABEL, STATUS_STYLE, type ContentStatus } from "@/lib/domain";
import { cn } from "@/lib/utils";

export function StatusChip({
  status,
  className,
}: {
  status: ContentStatus;
  className?: string;
}) {
  const style = STATUS_STYLE[status];
  return (
    <span
      className={cn(
        "inline-flex w-fit items-center gap-1.5 rounded-full px-2 py-1 text-[11px] font-medium",
        style.chip,
        className,
      )}
    >
      <span className={cn("size-1.5 rounded-full", style.dot)} />
      {STATUS_LABEL[status]}
    </span>
  );
}

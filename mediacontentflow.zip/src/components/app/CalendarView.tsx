import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { Content } from "@/lib/data";
import { STATUS_STYLE } from "@/lib/domain";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const WEEKDAYS = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"];
const MONTH_NAMES = [
  "janeiro",
  "fevereiro",
  "março",
  "abril",
  "maio",
  "junho",
  "julho",
  "agosto",
  "setembro",
  "outubro",
  "novembro",
  "dezembro",
];

const iso = (y: number, m: number, d: number) =>
  `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

export function CalendarView({
  contents,
  onOpen,
  onCreate,
}: {
  contents: Content[];
  onOpen: (content: Content) => void;
  onCreate: (date: string) => void;
}) {
  const today = new Date();
  const [cursor, setCursor] = useState({ year: today.getFullYear(), month: today.getMonth() });

  const byDate = useMemo(() => {
    const map = new Map<string, Content[]>();
    for (const c of contents) {
      if (!c.scheduled_date) continue;
      const list = map.get(c.scheduled_date) ?? [];
      list.push(c);
      map.set(c.scheduled_date, list);
    }
    return map;
  }, [contents]);

  const first = new Date(cursor.year, cursor.month, 1);
  const offset = (first.getDay() + 6) % 7; // segunda = 0
  const daysInMonth = new Date(cursor.year, cursor.month + 1, 0).getDate();
  const cells: (number | null)[] = [
    ...Array.from({ length: offset }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const shift = (delta: number) => {
    const next = new Date(cursor.year, cursor.month + delta, 1);
    setCursor({ year: next.getFullYear(), month: next.getMonth() });
  };

  return (
    <div className="rounded-xl bg-surface p-4 ring-1 ring-line/70">
      <header className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-lg">
          {MONTH_NAMES[cursor.month]} <span className="text-faint">{cursor.year}</span>
        </h3>
        <div className="flex gap-1">
          <Button variant="outline" size="icon" onClick={() => shift(-1)} aria-label="Mês anterior">
            <ChevronLeft className="size-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => shift(1)} aria-label="Próximo mês">
            <ChevronRight className="size-4" />
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-7 gap-1">
        {WEEKDAYS.map((d) => (
          <div key={d} className="label-mono pb-1 text-center text-faint">
            {d}
          </div>
        ))}
        {cells.map((day, index) => {
          if (day === null) return <div key={`empty-${index}`} />;
          const key = iso(cursor.year, cursor.month, day);
          const items = byDate.get(key) ?? [];
          const isToday =
            day === today.getDate() &&
            cursor.month === today.getMonth() &&
            cursor.year === today.getFullYear();
          return (
            <div
              key={key}
              onDoubleClick={() => onCreate(key)}
              className={cn(
                "min-h-24 rounded-lg bg-paper-deep/50 p-1.5 transition-colors hover:bg-paper-deep",
                isToday && "ring-1 ring-moss",
              )}
            >
              <span className={cn("label-mono", isToday ? "text-moss" : "text-faint")}>{day}</span>
              <div className="mt-1 space-y-1">
                {items.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onOpen(item)}
                    className="flex w-full items-center gap-1 rounded bg-surface px-1.5 py-1 text-left text-[11px] leading-tight ring-1 ring-line/60 hover:shadow-sm"
                  >
                    <span
                      className={cn("size-1.5 shrink-0 rounded-full", STATUS_STYLE[item.status].dot)}
                    />
                    <span className="truncate">{item.title}</span>
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Toque duas vezes em um dia para criar um conteúdo nessa data.
      </p>
    </div>
  );
}

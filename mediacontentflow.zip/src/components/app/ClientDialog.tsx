import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDeleteClient, useSaveClient, type Client } from "@/lib/data";
import { createClientAccess } from "@/lib/clientAccess.functions";

const empty = {
  name: "",
  company: "",
  niche: "",
  email: "",
  phone: "",
  instagram: "",
  drive_folder_url: "",
  notes: "",
};

export function ClientDialog({
  open,
  onOpenChange,
  client,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  client: Client | null;
}) {
  const [form, setForm] = useState(empty);
  const [access, setAccess] = useState({ email: "", password: "" });
  const [creatingAccess, setCreatingAccess] = useState(false);
  const save = useSaveClient();
  const remove = useDeleteClient();
  const grantAccess = useServerFn(createClientAccess);

  useEffect(() => {
    if (!open) return;
    setForm(
      client
        ? {
            name: client.name,
            company: client.company ?? "",
            niche: client.niche ?? "",
            email: client.email ?? "",
            phone: client.phone ?? "",
            instagram: client.instagram ?? "",
            drive_folder_url: client.drive_folder_url ?? "",
            notes: client.notes ?? "",
          }
        : empty,
    );
    setAccess({ email: client?.email ?? "", password: "" });
  }, [open, client]);

  const set = (key: keyof typeof empty, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const handleSave = async () => {
    if (!form.name.trim()) {
      toast.error("Informe o nome do cliente.");
      return;
    }
    try {
      await save.mutateAsync({
        id: client?.id,
        name: form.name.trim(),
        company: form.company || null,
        niche: form.niche || null,
        email: form.email || null,
        phone: form.phone || null,
        instagram: form.instagram || null,
        drive_folder_url: form.drive_folder_url || null,
        notes: form.notes || null,
      } as never);
      toast.success(client ? "Cliente atualizado." : "Cliente criado.");
      onOpenChange(false);
    } catch (error) {
      toast.error((error as Error).message);
    }
  };

  const handleAccess = async () => {
    if (!client) return;
    if (!access.email || access.password.length < 6) {
      toast.error("Informe um e-mail e uma senha de pelo menos 6 caracteres.");
      return;
    }
    setCreatingAccess(true);
    try {
      await grantAccess({
        data: {
          clientId: client.id,
          email: access.email.trim(),
          password: access.password,
          fullName: client.name,
        },
      });
      toast.success("Acesso do cliente pronto. Envie o e-mail e a senha para ele.");
      setAccess((prev) => ({ ...prev, password: "" }));
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      setCreatingAccess(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {client ? "Editar cliente" : "Novo cliente"}
          </DialogTitle>
          <DialogDescription>Dados do cliente e acesso ao portal de aprovação.</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="dados">
          <TabsList>
            <TabsTrigger value="dados">Dados</TabsTrigger>
            <TabsTrigger value="acesso" disabled={!client}>
              Acesso ao portal
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dados" className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome</Label>
              <Input id="name" value={form.name} onChange={(e) => set("name", e.target.value)} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  value={form.company}
                  onChange={(e) => set("company", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="niche">Nicho</Label>
                <Input
                  id="niche"
                  value={form.niche}
                  onChange={(e) => set("niche", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => set("email", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={form.phone}
                  onChange={(e) => set("phone", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="instagram">Instagram</Label>
                <Input
                  id="instagram"
                  value={form.instagram}
                  onChange={(e) => set("instagram", e.target.value)}
                  placeholder="@perfil"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="drive">Pasta de arquivos</Label>
                <Input
                  id="drive"
                  value={form.drive_folder_url}
                  onChange={(e) => set("drive_folder_url", e.target.value)}
                  placeholder="https://"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                rows={3}
                value={form.notes}
                onChange={(e) => set("notes", e.target.value)}
              />
            </div>
          </TabsContent>

          <TabsContent value="acesso" className="space-y-4 pt-4">
            <p className="text-sm text-muted-foreground">
              Crie um login para o cliente acompanhar e aprovar os conteúdos dele. Nenhum e-mail
              automático é enviado — combine a senha com ele.
            </p>
            <div className="space-y-2">
              <Label htmlFor="access-email">E-mail de acesso</Label>
              <Input
                id="access-email"
                type="email"
                value={access.email}
                onChange={(e) => setAccess((p) => ({ ...p, email: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="access-password">Senha</Label>
              <Input
                id="access-password"
                type="text"
                value={access.password}
                onChange={(e) => setAccess((p) => ({ ...p, password: e.target.value }))}
                placeholder="mínimo 6 caracteres"
              />
            </div>
            <Button onClick={handleAccess} disabled={creatingAccess}>
              {creatingAccess ? "Criando…" : "Criar / atualizar acesso"}
            </Button>
          </TabsContent>
        </Tabs>

        <DialogFooter className="gap-2 sm:justify-between">
          {client ? (
            <Button
              variant="ghost"
              className="text-wine"
              onClick={async () => {
                await remove.mutateAsync(client.id);
                toast.success("Cliente removido.");
                onOpenChange(false);
              }}
            >
              Excluir
            </Button>
          ) : (
            <span />
          )}
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={save.isPending}>
              Salvar
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

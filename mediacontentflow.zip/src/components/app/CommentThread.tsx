import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { Comment } from "@/lib/data";

export function CommentThread({
  comments,
  loading,
  onSend,
}: {
  comments: Comment[];
  loading?: boolean;
  onSend: (body: string) => Promise<void>;
}) {
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  const send = async () => {
    if (!text.trim()) return;
    setSending(true);
    try {
      await onSend(text.trim());
      setText("");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="space-y-2">
        {loading && <p className="text-sm text-muted-foreground">Carregando…</p>}
        {!loading && comments.length === 0 && (
          <p className="text-sm text-muted-foreground">Nenhum comentário ainda.</p>
        )}
        {comments.map((c) => (
          <div
            key={c.id}
            className="rounded-lg bg-paper-deep/70 p-3 ring-1 ring-line/70"
          >
            <p className="label-mono text-faint">
              {c.author_name} · {c.author_role === "client" ? "cliente" : "equipe"}
            </p>
            <p className="mt-1 text-sm leading-relaxed whitespace-pre-line">{c.body}</p>
          </div>
        ))}
      </div>
      <Textarea
        rows={3}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Escreva um comentário…"
      />
      <Button size="sm" onClick={send} disabled={sending || !text.trim()}>
        Enviar
      </Button>
    </div>
  );
}

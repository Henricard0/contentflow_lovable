import { PLATFORM_LABEL, shortDate } from "@/lib/domain";
import type { Content } from "@/lib/data";
import { StatusChip } from "./StatusChip";

export function ContentTable({
  contents,
  onOpen,
}: {
  contents: Content[];
  onOpen: (content: Content) => void;
}) {
  if (contents.length === 0) {
    return <p className="p-6 text-sm text-muted-foreground">Nenhum conteúdo por aqui ainda.</p>;
  }

  return (
    <div className="overflow-x-auto rounded-xl bg-surface ring-1 ring-line/70">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead>
          <tr className="border-b border-line/70">
            {["Conteúdo", "Plataforma", "Data", "Etapa", "Mídia"].map((h) => (
              <th key={h} className="label-mono px-4 py-3 text-faint">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {contents.map((item) => (
            <tr
              key={item.id}
              onClick={() => onOpen(item)}
              className="cursor-pointer border-b border-line/40 transition-colors last:border-0 hover:bg-paper-deep/60"
            >
              <td className="px-4 py-3">
                <p className="font-medium">{item.title}</p>
                {item.hook && (
                  <p className="line-clamp-1 text-xs text-muted-foreground">{item.hook}</p>
                )}
              </td>
              <td className="px-4 py-3 text-muted-foreground">{PLATFORM_LABEL[item.platform]}</td>
              <td className="px-4 py-3 text-muted-foreground">
                {shortDate(item.scheduled_date)}
                {item.scheduled_time ? ` · ${item.scheduled_time}` : ""}
              </td>
              <td className="px-4 py-3">
                <StatusChip status={item.status} />
              </td>
              <td className="px-4 py-3">
                {item.media_url ? (
                  <a
                    href={item.media_url}
                    target="_blank"
                    rel="noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="text-moss underline underline-offset-4"
                  >
                    abrir
                  </a>
                ) : (
                  <span className="text-faint">—</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

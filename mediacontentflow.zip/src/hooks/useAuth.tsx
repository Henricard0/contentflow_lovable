import { useEffect, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type Role = "creator" | "client" | null;

export interface AuthState {
  session: Session | null;
  role: Role;
  clientId: string | null;
  fullName: string;
  loading: boolean;
}

export function useAuth(): AuthState {
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<Role>(null);
  const [clientId, setClientId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    const loadRole = async (userId: string) => {
      const [{ data: roles }, { data: access }] = await Promise.all([
        supabase.from("user_roles").select("role").eq("user_id", userId),
        supabase.from("client_users").select("client_id").eq("user_id", userId).maybeSingle(),
      ]);
      if (!active) return;
      const isCreator = (roles ?? []).some((r) => r.role === "creator");
      setRole(isCreator ? "creator" : (roles ?? []).length ? "client" : null);
      setClientId(access?.client_id ?? null);
      setLoading(false);
    };

    const { data: sub } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!active) return;
      setSession(nextSession);
      if (nextSession?.user) {
        setLoading(true);
        setTimeout(() => void loadRole(nextSession.user.id), 0);
      } else {
        setRole(null);
        setClientId(null);
        setLoading(false);
      }
    });

    void supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      if (data.session?.user) void loadRole(data.session.user.id);
      else setLoading(false);
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const meta = session?.user.user_metadata as { full_name?: string } | undefined;

  return {
    session,
    role,
    clientId,
    fullName: meta?.full_name || session?.user.email || "",
    loading,
  };
}

export async function signOut() {
  await supabase.auth.signOut();
}
